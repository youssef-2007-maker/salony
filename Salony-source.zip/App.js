import React from 'react';
import { StatusBar } from 'expo-status-bar';
import { SafeAreaProvider } from 'react-native-safe-area-context';
import { NavigationContainer } from '@react-navigation/native';
import RootNavigator from './src/navigation/RootNavigator';
import { FavouritesProvider } from './src/state/FavouritesContext';
import { BookingsProvider } from './src/state/BookingsContext';
import { navTheme } from './src/theme/colors';

export default function App() {
  return (
    <SafeAreaProvider>
      <FavouritesProvider>
        <BookingsProvider>
          <NavigationContainer theme={navTheme}>
            <StatusBar style="light" />
            <RootNavigator />
          </NavigationContainer>
        </BookingsProvider>
      </FavouritesProvider>
    </SafeAreaProvider>
  );
}
