// Mock data matching the supplied designs.
// All prices in EGP. Replace with API data when backend is ready.

export const categories = [
  {
    id: 'hair',
    label: 'Hair & Styling',
    icon: 'cut',
  },
  {
    id: 'brows',
    label: 'Eyebrows & Eyelashes',
    icon: 'eye',
  },
  {
    id: 'nails',
    label: 'Nails',
    icon: 'color-palette',
  },
  {
    id: 'spa',
    label: 'Spa & Massage',
    icon: 'flower',
  },
  {
    id: 'makeup',
    label: 'Makeup',
    icon: 'sparkles',
  },
  {
    id: 'mens',
    label: "Men's Grooming",
    icon: 'man',
  },
];

export const barbers = [
  { id: 'any', name: 'Any', initial: '👤', isAny: true },
  { id: 'mohamed', name: 'Mohamed', initial: 'M', tint: 0 },
  { id: 'ramy', name: 'Ramy', initial: 'R', tint: 1 },
  { id: 'khalid', name: 'Khalid', initial: 'K', tint: 2 },
];

export const services = [
  {
    id: 'classic-haircut',
    title: 'Classic Haircut',
    duration: '45 min',
    details: 'Includes wash & dry',
    price: 200,
  },
  {
    id: 'beard-trim',
    title: 'Beard Trim & Shape',
    duration: '20 min',
    details: 'Hot towel finish',
    price: 120,
  },
  {
    id: 'haircut-beard',
    title: 'Haircut + Beard Combo',
    duration: '60 min',
    details: 'Full service',
    price: 280,
  },
  {
    id: 'kids-cut',
    title: "Kids' Haircut",
    duration: '30 min',
    details: 'Under 12 years',
    price: 150,
  },
];

export const salons = [
  {
    id: 'the-barber-shop',
    name: 'The Barber Shop',
    category: 'Hair Salon',
    address: 'El Marghany, Heliopolis',
    rating: 5.0,
    reviewCount: 248,
    distanceKm: 3.2,
    priceLabel: 'EGP',
    tags: ['Hair Salon'],
    services,
    barbers,
    hours: 'Open today 10:00 AM – 11:00 PM',
    about:
      'A modern grooming destination in the heart of Heliopolis. Premium haircuts, beard work and grooming rituals delivered by award-winning barbers.',
  },
  {
    id: 'lavish-studio',
    name: 'Lavish Hair Studio',
    category: 'Hair Salon',
    address: 'Sheikh Zayed, 6th of October',
    rating: 4.8,
    reviewCount: 412,
    distanceKm: 7.4,
    priceLabel: 'EGP',
    tags: ['Hair Salon', 'Color Specialist'],
    services: [
      { id: 'cut-blow', title: 'Cut & Blow Dry', duration: '60 min', details: 'Wash included', price: 350 },
      { id: 'highlights', title: 'Highlights', duration: '120 min', details: 'Up to mid-length', price: 1800 },
    ],
    barbers: [
      { id: 'any', name: 'Any', initial: '👤', isAny: true },
      { id: 'cynthia', name: 'Cynthia', initial: 'C', tint: 3 },
      { id: 'kris', name: 'Kris', initial: 'K', tint: 4 },
    ],
    hours: 'Open today 11:00 AM – 9:00 PM',
    about:
      'A high-end studio specialising in colour, balayage and bridal styling. Trusted by the city for over a decade.',
  },
  {
    id: 'glow-brows',
    name: 'Glow Brows & Lashes',
    category: 'Eyebrows & Lashes',
    address: 'Maadi, Cairo',
    rating: 4.9,
    reviewCount: 189,
    distanceKm: 5.6,
    priceLabel: 'EGP',
    tags: ['Eyebrows', 'Lashes'],
    services: [
      { id: 'brow-shape', title: 'Brow Shaping', duration: '30 min', details: 'Threading + tint', price: 180 },
      { id: 'lash-lift', title: 'Lash Lift', duration: '45 min', details: 'Lasts 6-8 weeks', price: 600 },
    ],
    barbers: [
      { id: 'any', name: 'Any', initial: '👤', isAny: true },
      { id: 'nour', name: 'Nour', initial: 'N', tint: 2 },
      { id: 'sara', name: 'Sara', initial: 'S', tint: 0 },
    ],
    hours: 'Open today 12:00 PM – 10:00 PM',
    about:
      'A cosy boutique focused on brow architecture and lash artistry. Walk in for a polished, natural finish.',
  },
];

export const initialBookings = [
  {
    id: 'bk-001',
    salonId: 'the-barber-shop',
    salonName: 'The Barber Shop',
    address: 'El Marghany, Heliopolis',
    serviceTitle: 'Classic Haircut',
    barberName: 'Mohamed',
    date: '2026-05-21',
    time: '11:00 AM',
    price: 200,
    status: 'upcoming',
  },
  {
    id: 'bk-002',
    salonId: 'lavish-studio',
    salonName: 'Lavish Hair Studio',
    address: 'Sheikh Zayed, 6th of October',
    serviceTitle: 'Cut & Blow Dry',
    barberName: 'Cynthia',
    date: '2026-04-30',
    time: '02:30 PM',
    price: 350,
    status: 'past',
  },
];

export const messages = [
  {
    id: 'm1',
    salonId: 'the-barber-shop',
    salonName: 'The Barber Shop',
    preview: 'Your appointment is confirmed. See you Friday!',
    time: '2h',
    unread: true,
  },
  {
    id: 'm2',
    salonId: 'lavish-studio',
    salonName: 'Lavish Hair Studio',
    preview: 'Thanks for visiting — leave us a quick review?',
    time: '3d',
    unread: false,
  },
];
