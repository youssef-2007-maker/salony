import React, { createContext, useContext, useMemo, useState, useCallback } from 'react';

const FavouritesContext = createContext(null);

export function FavouritesProvider({ children }) {
  const [favourites, setFavourites] = useState(new Set(['the-barber-shop']));

  const toggle = useCallback((id) => {
    setFavourites((prev) => {
      const next = new Set(prev);
      if (next.has(id)) next.delete(id);
      else next.add(id);
      return next;
    });
  }, []);

  const isFavourite = useCallback((id) => favourites.has(id), [favourites]);

  const value = useMemo(
    () => ({ favourites: Array.from(favourites), toggle, isFavourite }),
    [favourites, toggle, isFavourite]
  );

  return <FavouritesContext.Provider value={value}>{children}</FavouritesContext.Provider>;
}

export function useFavourites() {
  const ctx = useContext(FavouritesContext);
  if (!ctx) throw new Error('useFavourites must be used inside FavouritesProvider');
  return ctx;
}
