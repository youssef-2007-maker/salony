import React, { createContext, useContext, useMemo, useState, useCallback } from 'react';
import { initialBookings } from '../data/salons';

const BookingsContext = createContext(null);

export function BookingsProvider({ children }) {
  const [bookings, setBookings] = useState(initialBookings);

  const addBooking = useCallback((b) => {
    setBookings((prev) => [{ ...b, id: `bk-${Date.now()}`, status: 'upcoming' }, ...prev]);
  }, []);

  const cancelBooking = useCallback((id) => {
    setBookings((prev) => prev.map((b) => (b.id === id ? { ...b, status: 'cancelled' } : b)));
  }, []);

  const value = useMemo(
    () => ({
      bookings,
      upcoming: bookings.filter((b) => b.status === 'upcoming'),
      past: bookings.filter((b) => b.status === 'past' || b.status === 'cancelled'),
      addBooking,
      cancelBooking,
    }),
    [bookings, addBooking, cancelBooking]
  );

  return <BookingsContext.Provider value={value}>{children}</BookingsContext.Provider>;
}

export function useBookings() {
  const ctx = useContext(BookingsContext);
  if (!ctx) throw new Error('useBookings must be used inside BookingsProvider');
  return ctx;
}
