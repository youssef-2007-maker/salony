import React from 'react';
import { View, Text, StyleSheet, ScrollView, Pressable, Alert, Switch } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { Ionicons } from '@expo/vector-icons';
import { colors, radius, shadow, spacing, typography } from '../theme/colors';

const MENU = [
  { id: 'edit', icon: 'person-outline', label: 'Edit profile' },
  { id: 'payments', icon: 'card-outline', label: 'Payment methods' },
  { id: 'addresses', icon: 'location-outline', label: 'Saved addresses' },
  { id: 'support', icon: 'help-circle-outline', label: 'Help & Support' },
  { id: 'terms', icon: 'document-text-outline', label: 'Terms & Privacy' },
];

export default function ProfileScreen() {
  const [notifications, setNotifications] = React.useState(true);
  const [reminders, setReminders] = React.useState(true);

  return (
    <SafeAreaView style={styles.root} edges={['top']}>
      <ScrollView contentContainerStyle={{ paddingBottom: spacing.xxl }}>
        <View style={styles.header}>
          <View style={styles.avatar}>
            <Text style={styles.avatarText}>Y</Text>
          </View>
          <Text style={styles.name}>Youssef</Text>
          <Text style={styles.email}>tgbybh7gt2@privaterelay.appleid.com</Text>
          <Pressable style={styles.editBtn}>
            <Text style={styles.editBtnText}>Edit profile</Text>
          </Pressable>
        </View>

        <View style={[styles.card, shadow.card]}>
          <SettingRow
            icon="notifications-outline"
            label="Push notifications"
            right={
              <Switch
                value={notifications}
                onValueChange={setNotifications}
                trackColor={{ true: colors.primary, false: colors.disabled }}
                thumbColor="#fff"
              />
            }
          />
          <SettingRow
            icon="alarm-outline"
            label="Appointment reminders"
            right={
              <Switch
                value={reminders}
                onValueChange={setReminders}
                trackColor={{ true: colors.primary, false: colors.disabled }}
                thumbColor="#fff"
              />
            }
          />
        </View>

        <View style={[styles.card, shadow.card]}>
          {MENU.map((m, i) => (
            <SettingRow
              key={m.id}
              icon={m.icon}
              label={m.label}
              divider={i < MENU.length - 1}
              right={<Ionicons name="chevron-forward" size={18} color={colors.textMuted} />}
              onPress={() => Alert.alert(m.label, 'Coming soon.')}
            />
          ))}
        </View>

        <Pressable
          style={styles.signOut}
          onPress={() => Alert.alert('Sign out', 'Are you sure?')}
        >
          <Ionicons name="log-out-outline" size={18} color={colors.danger} />
          <Text style={styles.signOutText}>Sign out</Text>
        </Pressable>

        <Text style={styles.version}>Salony v1.0.0</Text>
      </ScrollView>
    </SafeAreaView>
  );
}

function SettingRow({ icon, label, right, divider, onPress }) {
  return (
    <Pressable
      onPress={onPress}
      style={[styles.settingRow, divider && styles.divider]}
    >
      <View style={styles.iconBubble}>
        <Ionicons name={icon} size={18} color={colors.primary} />
      </View>
      <Text style={styles.settingLabel}>{label}</Text>
      <View style={{ marginLeft: 'auto' }}>{right}</View>
    </Pressable>
  );
}

const styles = StyleSheet.create({
  root: { flex: 1, backgroundColor: colors.bg },
  header: { alignItems: 'center', padding: spacing.lg },
  avatar: {
    width: 88,
    height: 88,
    borderRadius: 44,
    backgroundColor: colors.primary,
    alignItems: 'center',
    justifyContent: 'center',
    marginBottom: spacing.md,
  },
  avatarText: { color: '#fff', fontSize: 36, fontWeight: '800' },
  name: { ...typography.h1, color: colors.text },
  email: { ...typography.small, color: colors.textMuted, marginTop: 2 },
  editBtn: {
    marginTop: spacing.md,
    paddingHorizontal: 18,
    paddingVertical: 8,
    borderRadius: radius.pill,
    borderWidth: 1,
    borderColor: colors.primary,
  },
  editBtnText: { color: colors.primary, fontWeight: '700' },

  card: {
    backgroundColor: colors.surface,
    borderRadius: radius.lg,
    marginHorizontal: spacing.lg,
    marginBottom: spacing.md,
    paddingHorizontal: spacing.md,
  },
  settingRow: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingVertical: 14,
  },
  divider: { borderBottomWidth: 1, borderBottomColor: colors.border },
  iconBubble: {
    width: 36,
    height: 36,
    borderRadius: 18,
    backgroundColor: colors.surfaceMuted,
    alignItems: 'center',
    justifyContent: 'center',
    marginRight: spacing.md,
  },
  settingLabel: { color: colors.text, fontWeight: '600' },

  signOut: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    padding: spacing.md,
    marginTop: spacing.md,
  },
  signOutText: { color: colors.danger, marginLeft: 6, fontWeight: '700' },
  version: { textAlign: 'center', color: colors.textMuted, marginTop: spacing.md, fontSize: 12 },
});
