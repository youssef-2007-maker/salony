import React from 'react';
import { View, Text, StyleSheet, ScrollView, Pressable } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { Ionicons } from '@expo/vector-icons';
import { colors, radius, shadow, spacing, typography } from '../theme/colors';
import { salons } from '../data/salons';
import ServiceRow from '../components/ServiceRow';
import { useFavourites } from '../state/FavouritesContext';

export default function SalonDetailScreen({ route, navigation }) {
  const { salonId } = route.params;
  const salon = salons.find((s) => s.id === salonId);
  const { isFavourite, toggle } = useFavourites();

  if (!salon) {
    return (
      <SafeAreaView style={styles.root}>
        <Text style={{ padding: 24 }}>Salon not found.</Text>
      </SafeAreaView>
    );
  }

  const fav = isFavourite(salon.id);

  return (
    <View style={styles.root}>
      <SafeAreaView edges={['top']} style={styles.header}>
        <View style={styles.headerInner}>
          <Pressable onPress={() => navigation.goBack()} hitSlop={10}>
            <Ionicons name="chevron-back" size={24} color="#fff" />
          </Pressable>
          <Pressable onPress={() => toggle(salon.id)} hitSlop={10}>
            <Ionicons
              name={fav ? 'heart' : 'heart-outline'}
              size={24}
              color="#fff"
            />
          </Pressable>
        </View>
        <View style={styles.headerBody}>
          <Text style={styles.salonName}>{salon.name}</Text>
          <Text style={styles.salonMeta}>
            {salon.category}  ·  {salon.address}
          </Text>
          <View style={styles.statsRow}>
            <View style={styles.stat}>
              <Ionicons name="star" size={14} color="#FFD27A" />
              <Text style={styles.statText}>
                {salon.rating.toFixed(1)} ({salon.reviewCount})
              </Text>
            </View>
            <View style={styles.stat}>
              <Ionicons name="location-outline" size={14} color="#fff" />
              <Text style={styles.statText}>{salon.distanceKm} km</Text>
            </View>
            <View style={styles.stat}>
              <Ionicons name="time-outline" size={14} color="#fff" />
              <Text style={styles.statText} numberOfLines={1}>{salon.hours}</Text>
            </View>
          </View>
        </View>
      </SafeAreaView>

      <ScrollView
        style={{ flex: 1 }}
        contentContainerStyle={{ padding: spacing.lg, paddingBottom: 120 }}
        showsVerticalScrollIndicator={false}
      >
        <View style={[styles.aboutCard, shadow.card]}>
          <Text style={styles.sectionTitle}>About</Text>
          <Text style={styles.aboutText}>{salon.about}</Text>
        </View>

        <Text style={[styles.sectionTitle, { marginTop: spacing.xl }]}>Services</Text>
        {salon.services.map((service) => (
          <ServiceRow
            key={service.id}
            service={service}
            onPress={() =>
              navigation.navigate('Booking', { salonId: salon.id, serviceId: service.id })
            }
          />
        ))}
      </ScrollView>
    </View>
  );
}

const styles = StyleSheet.create({
  root: { flex: 1, backgroundColor: colors.bg },
  header: { backgroundColor: colors.primary },
  headerInner: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    paddingHorizontal: spacing.lg,
    paddingTop: spacing.sm,
  },
  headerBody: {
    paddingHorizontal: spacing.lg,
    paddingTop: spacing.sm,
    paddingBottom: spacing.xl,
  },
  salonName: { ...typography.display, color: '#fff' },
  salonMeta: { color: 'rgba(255,255,255,0.85)', marginTop: 4 },
  statsRow: { flexDirection: 'row', marginTop: spacing.md, flexWrap: 'wrap' },
  stat: { flexDirection: 'row', alignItems: 'center', marginRight: 16, marginTop: 6 },
  statText: { color: '#fff', marginLeft: 4, fontSize: 12, fontWeight: '600' },

  aboutCard: {
    backgroundColor: colors.surface,
    borderRadius: radius.lg,
    padding: spacing.lg,
  },
  sectionTitle: { ...typography.h1, color: colors.text, marginBottom: spacing.md },
  aboutText: { color: colors.textMuted, lineHeight: 20 },
});
