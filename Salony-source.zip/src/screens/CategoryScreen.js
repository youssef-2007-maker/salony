import React, { useMemo } from 'react';
import { View, Text, StyleSheet, Pressable, FlatList } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { Ionicons } from '@expo/vector-icons';
import { colors, spacing, typography } from '../theme/colors';
import { salons, categories } from '../data/salons';
import SalonCard from '../components/SalonCard';

export default function CategoryScreen({ route, navigation }) {
  const { categoryId } = route.params;
  const category = categories.find((c) => c.id === categoryId);

  const list = useMemo(() => {
    // very simple matching against tags/category fields
    const map = {
      hair: ['Hair Salon'],
      brows: ['Eyebrows', 'Lashes'],
    };
    const wanted = map[categoryId];
    if (!wanted) return salons;
    return salons.filter((s) => s.tags.some((t) => wanted.includes(t)));
  }, [categoryId]);

  return (
    <SafeAreaView style={styles.root} edges={['top']}>
      <View style={styles.header}>
        <Pressable onPress={() => navigation.goBack()} hitSlop={10}>
          <Ionicons name="chevron-back" size={24} color={colors.text} />
        </Pressable>
        <Text style={styles.title}>{category?.label ?? 'Category'}</Text>
        <View style={{ width: 24 }} />
      </View>
      <FlatList
        data={list}
        keyExtractor={(s) => s.id}
        contentContainerStyle={{ padding: spacing.lg }}
        renderItem={({ item }) => (
          <SalonCard
            wide
            salon={item}
            onPress={() => navigation.navigate('SalonDetail', { salonId: item.id })}
          />
        )}
        ListEmptyComponent={
          <Text style={{ color: colors.textMuted, textAlign: 'center', marginTop: 40 }}>
            No salons in this category yet.
          </Text>
        }
      />
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  root: { flex: 1, backgroundColor: colors.bg },
  header: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    paddingHorizontal: spacing.lg,
    paddingVertical: spacing.md,
  },
  title: { ...typography.h1, color: colors.text },
});
