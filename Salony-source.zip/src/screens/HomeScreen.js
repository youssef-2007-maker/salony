import React from 'react';
import {
  View,
  Text,
  StyleSheet,
  ScrollView,
  Pressable,
  TextInput,
  FlatList,
} from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { Ionicons } from '@expo/vector-icons';
import { colors, radius, spacing, typography, shadow } from '../theme/colors';
import { salons, categories } from '../data/salons';
import SalonCard from '../components/SalonCard';
import CategoryCard from '../components/CategoryCard';
import SectionHeader from '../components/SectionHeader';

export default function HomeScreen({ navigation }) {
  return (
    <View style={styles.root}>
      <SafeAreaView edges={['top']} style={styles.header}>
        <View style={styles.headerInner}>
          <View>
            <Text style={styles.locLabel}>Location</Text>
            <View style={{ flexDirection: 'row', alignItems: 'center' }}>
              <Ionicons name="location" size={16} color="#fff" />
              <Text style={styles.locName}>  Al Rehab, Tagamo Al Khamis</Text>
              <Ionicons name="chevron-down" size={16} color="#fff" style={{ marginLeft: 4 }} />
            </View>
          </View>
          <Pressable onPress={() => navigation.navigate('Tabs', { screen: 'Profile' })}>
            <Ionicons name="notifications-outline" size={22} color="#fff" />
          </Pressable>
        </View>
      </SafeAreaView>

      <ScrollView
        style={{ flex: 1 }}
        contentContainerStyle={{ paddingBottom: spacing.xxl }}
        showsVerticalScrollIndicator={false}
      >
        <Pressable
          style={[styles.searchBar, shadow.card]}
          onPress={() => navigation.navigate('Search')}
        >
          <Ionicons name="search" size={18} color={colors.textMuted} />
          <TextInput
            placeholder="Search salons, services…"
            placeholderTextColor={colors.textMuted}
            style={styles.searchInput}
            editable={false}
            pointerEvents="none"
          />
        </Pressable>

        <View style={styles.hero}>
          <View style={{ flex: 1 }}>
            <Text style={styles.heroTitle}>Grooming{'\n'}made simple</Text>
            <Pressable
              onPress={() => navigation.navigate('SalonDetail', { salonId: 'the-barber-shop' })}
              style={styles.heroBtn}
            >
              <Text style={styles.heroBtnText}>Book now</Text>
            </Pressable>
          </View>
          <View style={styles.heroImg}>
            <Ionicons name="cut" size={48} color="#fff" />
          </View>
        </View>

        <SectionHeader
          title="Recommended"
          actionLabel="See all"
          onPress={() => navigation.navigate('Search')}
        />
        <FlatList
          data={salons}
          keyExtractor={(s) => s.id}
          horizontal
          showsHorizontalScrollIndicator={false}
          contentContainerStyle={{ paddingHorizontal: spacing.lg }}
          renderItem={({ item }) => (
            <SalonCard
              salon={item}
              onPress={() => navigation.navigate('SalonDetail', { salonId: item.id })}
            />
          )}
        />

        <SectionHeader title="Categories" />
        <View style={styles.catGrid}>
          {categories.map((c) => (
            <CategoryCard
              key={c.id}
              category={c}
              onPress={() => navigation.navigate('Category', { categoryId: c.id })}
            />
          ))}
        </View>
      </ScrollView>
    </View>
  );
}

const styles = StyleSheet.create({
  root: { flex: 1, backgroundColor: colors.bg },
  header: { backgroundColor: colors.primary },
  headerInner: {
    paddingHorizontal: spacing.lg,
    paddingTop: spacing.md,
    paddingBottom: spacing.xxl,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
  },
  locLabel: { color: 'rgba(255,255,255,0.7)', fontSize: 12 },
  locName: { color: '#fff', fontWeight: '700', fontSize: 14 },

  searchBar: {
    marginTop: -spacing.lg,
    marginHorizontal: spacing.lg,
    backgroundColor: colors.surface,
    borderRadius: radius.md,
    paddingHorizontal: spacing.md,
    paddingVertical: 12,
    flexDirection: 'row',
    alignItems: 'center',
  },
  searchInput: {
    flex: 1,
    marginLeft: 8,
    color: colors.text,
    fontSize: 14,
  },

  hero: {
    marginTop: spacing.lg,
    marginHorizontal: spacing.lg,
    backgroundColor: colors.primary,
    borderRadius: radius.lg,
    padding: spacing.lg,
    flexDirection: 'row',
    alignItems: 'center',
    minHeight: 160,
  },
  heroTitle: { ...typography.display, color: '#fff', marginBottom: 16 },
  heroBtn: {
    alignSelf: 'flex-start',
    backgroundColor: '#fff',
    paddingHorizontal: spacing.lg,
    paddingVertical: 10,
    borderRadius: radius.md,
  },
  heroBtnText: { color: colors.primary, fontWeight: '800' },
  heroImg: {
    width: 110,
    height: 110,
    borderRadius: 55,
    backgroundColor: 'rgba(255,255,255,0.15)',
    alignItems: 'center',
    justifyContent: 'center',
    marginLeft: spacing.md,
  },

  catGrid: {
    paddingHorizontal: spacing.lg,
    flexDirection: 'row',
    flexWrap: 'wrap',
    justifyContent: 'space-between',
  },
});
