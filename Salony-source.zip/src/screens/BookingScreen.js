import React, { useMemo, useState } from 'react';
import { View, Text, StyleSheet, ScrollView, Pressable, Alert } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { Ionicons } from '@expo/vector-icons';
import { colors, radius, shadow, spacing, typography } from '../theme/colors';
import { salons } from '../data/salons';
import { getUpcomingDates, getDailySlots } from '../data/dates';
import BarberAvatar from '../components/BarberAvatar';
import DateChip from '../components/DateChip';
import Pill from '../components/Pill';
import PrimaryButton from '../components/PrimaryButton';
import { useBookings } from '../state/BookingsContext';

export default function BookingScreen({ route, navigation }) {
  const { salonId, serviceId } = route.params;
  const salon = salons.find((s) => s.id === salonId);
  const service = salon?.services.find((s) => s.id === serviceId) ?? salon?.services[0];
  const dates = useMemo(() => getUpcomingDates(14), []);
  const slots = useMemo(() => getDailySlots(), []);
  const { addBooking } = useBookings();

  const [barber, setBarber] = useState(salon.barbers[1]?.id ?? salon.barbers[0].id);
  const [date, setDate] = useState(dates[1]?.iso ?? dates[0].iso);
  const [time, setTime] = useState('11:00 AM');

  const canConfirm = barber && date && time;

  const onConfirm = () => {
    const chosenBarber = salon.barbers.find((b) => b.id === barber);
    addBooking({
      salonId: salon.id,
      salonName: salon.name,
      address: salon.address,
      serviceTitle: service.title,
      barberName: chosenBarber?.name ?? 'Any',
      date,
      time,
      price: service.price,
    });
    navigation.replace('BookingConfirmation', {
      salonName: salon.name,
      serviceTitle: service.title,
      barberName: chosenBarber?.name ?? 'Any',
      date,
      time,
      price: service.price,
    });
  };

  return (
    <View style={styles.root}>
      <SafeAreaView edges={['top']} style={styles.header}>
        <View style={styles.headerInner}>
          <Pressable onPress={() => navigation.goBack()} hitSlop={10}>
            <Ionicons name="chevron-back" size={22} color="#fff" />
          </Pressable>
          <Text style={styles.headerBack}>Back</Text>
        </View>
        <View style={{ paddingHorizontal: spacing.lg, paddingBottom: spacing.xl }}>
          <Text style={styles.salonName}>{salon.name}</Text>
          <Text style={styles.salonMeta}>
            {salon.category}  {salon.address}
          </Text>
        </View>
      </SafeAreaView>

      <ScrollView
        style={{ flex: 1 }}
        contentContainerStyle={{ padding: spacing.lg, paddingBottom: 160 }}
        showsVerticalScrollIndicator={false}
      >
        <View style={[styles.serviceCard, shadow.card]}>
          <View style={styles.serviceIcon}>
            <Ionicons name="cut" size={22} color="#fff" />
          </View>
          <View style={{ flex: 1, marginLeft: spacing.md }}>
            <Text style={styles.serviceTitle}>{service.title}</Text>
            <Text style={styles.serviceMeta}>
              {service.duration} · {service.details}
            </Text>
          </View>
          <Text style={styles.servicePrice}>{service.price} EGP</Text>
        </View>

        <Text style={styles.label}>Choose Barber</Text>
        <ScrollView
          horizontal
          showsHorizontalScrollIndicator={false}
          contentContainerStyle={{ paddingVertical: 4 }}
        >
          {salon.barbers.map((b) => (
            <BarberAvatar
              key={b.id}
              barber={b}
              active={barber === b.id}
              onPress={() => setBarber(b.id)}
            />
          ))}
        </ScrollView>

        <Text style={styles.label}>Select Date</Text>
        <ScrollView
          horizontal
          showsHorizontalScrollIndicator={false}
          contentContainerStyle={{ paddingVertical: 4 }}
        >
          {dates.map((d) => (
            <DateChip
              key={d.iso}
              day={d.day}
              label={d.label}
              active={date === d.iso}
              onPress={() => setDate(d.iso)}
            />
          ))}
        </ScrollView>

        <Text style={styles.label}>Select Time</Text>
        <View style={styles.slotGrid}>
          {slots.map((s) => (
            <Pill
              key={s.label}
              label={s.label}
              active={time === s.label}
              disabled={!s.available}
              onPress={() => setTime(s.label)}
              style={styles.slot}
            />
          ))}
        </View>
      </ScrollView>

      <View style={styles.footer}>
        <View>
          <Text style={styles.totalLabel}>Total</Text>
          <Text style={styles.totalPrice}>{service.price} EGP</Text>
        </View>
        <PrimaryButton
          title="Confirm Booking"
          onPress={onConfirm}
          disabled={!canConfirm}
          style={{ flex: 1, marginLeft: spacing.md }}
        />
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  root: { flex: 1, backgroundColor: colors.bg },
  header: { backgroundColor: colors.primary },
  headerInner: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingHorizontal: spacing.lg,
    paddingTop: spacing.sm,
  },
  headerBack: { color: '#fff', marginLeft: 4, fontWeight: '600' },
  salonName: { ...typography.h1, color: '#fff', marginTop: spacing.sm },
  salonMeta: { color: 'rgba(255,255,255,0.85)', marginTop: 4 },

  serviceCard: {
    backgroundColor: colors.surface,
    borderRadius: radius.lg,
    padding: spacing.md,
    flexDirection: 'row',
    alignItems: 'center',
    marginTop: -spacing.xl,
  },
  serviceIcon: {
    width: 48,
    height: 48,
    borderRadius: radius.md,
    backgroundColor: colors.primary,
    alignItems: 'center',
    justifyContent: 'center',
  },
  serviceTitle: { ...typography.h2, color: colors.text },
  serviceMeta: { ...typography.small, color: colors.textMuted, marginTop: 2 },
  servicePrice: { ...typography.h2, color: colors.primary },

  label: {
    ...typography.h2,
    color: colors.text,
    marginTop: spacing.xl,
    marginBottom: spacing.md,
  },
  slotGrid: { flexDirection: 'row', flexWrap: 'wrap' },
  slot: { width: '31%', marginRight: '3.5%', marginBottom: 10 },

  footer: {
    position: 'absolute',
    bottom: 0,
    left: 0,
    right: 0,
    backgroundColor: colors.surface,
    borderTopWidth: 1,
    borderTopColor: colors.border,
    padding: spacing.lg,
    paddingBottom: spacing.xl,
    flexDirection: 'row',
    alignItems: 'center',
  },
  totalLabel: { color: colors.textMuted, fontSize: 12 },
  totalPrice: { ...typography.h1, color: colors.text },
});
