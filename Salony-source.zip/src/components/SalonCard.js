import React from 'react';
import { Pressable, View, Text, StyleSheet } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { colors, radius, shadow, spacing, typography } from '../theme/colors';
import { useFavourites } from '../state/FavouritesContext';

export default function SalonCard({ salon, onPress, wide }) {
  const { isFavourite, toggle } = useFavourites();
  const fav = isFavourite(salon.id);

  return (
    <Pressable
      onPress={onPress}
      style={[styles.card, wide && styles.wide, shadow.card]}
    >
      <View style={styles.logoWrap}>
        <Text style={styles.logoText}>
          {salon.name
            .split(' ')
            .slice(0, 2)
            .map((w) => w[0])
            .join('')}
        </Text>
      </View>
      <View style={styles.body}>
        <View style={{ flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between' }}>
          <Text numberOfLines={1} style={styles.name}>
            {salon.name}
          </Text>
          <Pressable onPress={() => toggle(salon.id)} hitSlop={10}>
            <Ionicons
              name={fav ? 'heart' : 'heart-outline'}
              size={20}
              color={fav ? colors.primary : colors.textMuted}
            />
          </Pressable>
        </View>
        <View style={styles.metaRow}>
          <Ionicons name="star" size={14} color={colors.accent} />
          <Text style={styles.metaText}>
            {salon.rating.toFixed(1)} ({salon.reviewCount})
          </Text>
          <Text style={[styles.metaText, { marginLeft: 8 }]}>· {salon.distanceKm} km</Text>
        </View>
        <View style={styles.tagRow}>
          {salon.tags.map((t) => (
            <View key={t} style={styles.tag}>
              <Text style={styles.tagText}>{t}</Text>
            </View>
          ))}
        </View>
      </View>
    </Pressable>
  );
}

const styles = StyleSheet.create({
  card: {
    backgroundColor: colors.surface,
    borderRadius: radius.lg,
    padding: spacing.md,
    width: 260,
    marginRight: spacing.md,
  },
  wide: { width: '100%', marginRight: 0, marginBottom: spacing.md, flexDirection: 'row' },
  logoWrap: {
    width: 56,
    height: 56,
    borderRadius: radius.md,
    backgroundColor: colors.surfaceMuted,
    alignItems: 'center',
    justifyContent: 'center',
    marginRight: spacing.md,
  },
  logoText: { fontSize: 18, fontWeight: '800', color: colors.primary },
  body: { flex: 1, justifyContent: 'center' },
  name: { ...typography.h2, color: colors.text, flex: 1, marginRight: 8 },
  metaRow: { flexDirection: 'row', alignItems: 'center', marginTop: 4 },
  metaText: { ...typography.small, color: colors.textMuted, marginLeft: 4 },
  tagRow: { flexDirection: 'row', marginTop: 8, flexWrap: 'wrap' },
  tag: {
    backgroundColor: colors.surfaceMuted,
    borderRadius: radius.sm,
    paddingHorizontal: 8,
    paddingVertical: 4,
    marginRight: 6,
    marginBottom: 4,
  },
  tagText: { ...typography.tiny, color: colors.textMuted },
});
