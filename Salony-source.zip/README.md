# Salony

A salon & barbershop booking app for Egypt — built with **React Native + Expo** so a single codebase ships to both **Google Play** and the **App Store**.

The starter implementation in this repo covers the full booking flow from the supplied mock-ups:

- Home — location header, search, "Grooming made simple" hero, Recommended salons, Categories grid.
- Search — live filter across salons, addresses, tags and services.
- Category — narrows the salon list to one category.
- Salon detail — about, hours, ratings, services menu.
- Booking — service summary, "Choose Barber" picker (Any · Mohamed · Ramy · Khalid), 14-day date strip, 30-min time slots, sticky total + confirm.
- Booking confirmation — green tick screen with full booking summary.
- Bookings — Upcoming / Past tabs, cancel & reschedule actions.
- Favourites — list of hearted salons, persists for the session.
- Messages — inbox of salon conversations.
- Profile — avatar, settings card, push / reminder toggles, sign-out.

## Run it locally

You'll need Node 18+ and the Expo Go app on your phone (or an Android/iOS simulator).

```bash
cd Salony
npm install
npx expo start
```

Scan the QR code with Expo Go (Android) or the Camera app (iOS). The app reloads automatically as you edit.

> No backend yet — all data is mocked in `src/data/salons.js`. Drop in your API client when ready.

## Project layout

```
Salony/
├─ App.js                 # Providers + NavigationContainer
├─ index.js               # registerRootComponent
├─ app.json               # Expo config (icons, bundle IDs, permissions)
├─ eas.json               # Cloud build profiles (development / preview / production)
├─ babel.config.js
└─ src/
   ├─ theme/colors.js     # Burgundy design tokens (#7D1A3D), spacing, shadows
   ├─ data/               # Mock salons, services, bookings, date helpers
   ├─ state/              # Favourites + Bookings React contexts
   ├─ navigation/         # Stack + bottom tabs
   ├─ components/         # SalonCard, ServiceRow, BarberAvatar, DateChip, Pill, …
   └─ screens/            # One file per screen
```

## Replacing the icons & splash

Drop your own PNGs into `./assets/`:

- `icon.png` — 1024×1024
- `adaptive-icon.png` — 1024×1024 with safe area (foreground only)
- `splash.png` — 1284×2778 recommended
- `favicon.png` — 48×48 for the web build

The current `app.json` already wires those paths and sets the burgundy `#7D1A3D` as the splash background.

## Releasing to the App Store & Google Play

The app is wired for **EAS Build** (Expo's cloud build service):

```bash
# Once, on your machine
npm install -g eas-cli
eas login

# Set up the project (creates an EAS project ID — replace the placeholder in app.json)
eas init

# Cloud builds
npm run build:android    # → AAB for Play Store
npm run build:ios        # → IPA for App Store Connect

# Submit
npm run submit:android   # uploads AAB to Google Play
npm run submit:ios       # uploads IPA to App Store Connect
```

Before submitting, in `app.json`:

1. Replace `"bundleIdentifier": "com.salony.app"` and `"package": "com.salony.app"` with values registered to your developer accounts.
2. Bump `version`, `buildNumber` (iOS), and `versionCode` (Android) for each release — or let EAS auto-increment via the `production` profile in `eas.json`.
3. Add real `NSLocationWhenInUseUsageDescription` copy if you switch on real location lookups.

Store listings need: app name, short & full descriptions, 5+ screenshots per device size, a 1024×1024 icon, privacy policy URL, and an age rating. Anthropic's tooling can help you generate the marketing copy and screenshots when you're ready.

## Where to plug in a backend

- **Auth** — wire `ProfileScreen` to OAuth (Firebase, Supabase, or your own).
- **Data** — replace `src/data/salons.js` with API calls. Each screen already consumes the mock arrays in one place.
- **Bookings** — `src/state/BookingsContext.js` is the single write path; swap `addBooking` for a `POST /bookings` call.
- **Payments** — Stripe / Paymob (popular in Egypt) can be added to the confirmation step.
- **Push notifications** — `expo-notifications` works out of the box with the `notifications` toggle in `ProfileScreen`.

Happy shipping ✂️
