// Static UI catalogues. All live data (salons, services, barbers, bookings,
// messages) now comes from the backend via src/api/client.js.

export const categories = [
  { id: 'hair',   label: 'Hair & Styling',          icon: 'cut',             match: ['Hair Salon'] },
  { id: 'brows',  label: 'Eyebrows & Eyelashes',    icon: 'eye',             match: ['Eyebrows', 'Lashes', 'Eyebrows & Lashes'] },
  { id: 'nails',  label: 'Nails',                   icon: 'color-palette',   match: ['Nails'] },
  { id: 'spa',    label: 'Spa & Massage',           icon: 'flower',          match: ['Spa', 'Massage', 'Spa & Massage'] },
  { id: 'makeup', label: 'Makeup',                  icon: 'sparkles',        match: ['Makeup'] },
  { id: 'mens',   label: "Men's Grooming",          icon: 'man',             match: ["Men's Grooming"] },
];

export function findCategory(id) {
  return categories.find((c) => c.id === id);
}
